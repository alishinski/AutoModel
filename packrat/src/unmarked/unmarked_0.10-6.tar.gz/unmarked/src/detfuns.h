
#ifndef _UNMARKED_DETFUNS_H
#define _UNMARKED_DETFUNS_H

void grhn(double *x, int n, void *ex);
void gxhn(double *x, int n, void *ex);
void grexp(double *x, int n, void *ex);
void gxexp(double *x, int n, void *ex);
void grhaz(double *x, int n, void *ex);
void gxhaz(double *x, int n, void *ex);


#endif
