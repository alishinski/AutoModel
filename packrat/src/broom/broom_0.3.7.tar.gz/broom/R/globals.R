globalVariables(c(".", "estimate", "std.error", "statistic", "term", "p.value",
                "effect", "se", "objs", "comp", "N", "lambda", "GCV", "obs",
                ".id", "level", "group1", "group2", "series", "value",
                "index", "df.residual", "stratum", "conf.low", "conf.high"))
