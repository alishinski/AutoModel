varDescribeBy <- function(Data,IVList)
{ 
  by(Data, IVList, varDescribe)
}